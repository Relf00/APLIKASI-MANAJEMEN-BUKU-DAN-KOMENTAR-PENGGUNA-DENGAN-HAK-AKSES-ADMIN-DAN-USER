package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
	"strings"
)

const MAKS_BUKU = 100
const MAKS_KOMENTAR = 200
const MAKS_PENGGUNA = 50

const PERAN_ADMIN = "admin"
const PERAN_USER = "user"

type Pengguna struct {
	username string
	password string
	peran    string
}

type Buku struct {
	judul    string
	penulis  string
	tahun    int
	sinopsis string
}

type Komentar struct {
	usernamePengomentar string
	isiKomentar         string
	indeksBuku          int
	merupakanBalasan    bool
	indeksKomentarInduk int
}

var dataPengguna [MAKS_PENGGUNA]Pengguna
var jumlahPengguna int

var dataBuku [MAKS_BUKU]Buku
var jumlahBuku int

var dataKomentar [MAKS_KOMENTAR]Komentar
var jumlahKomentar int

func bacaInputString(prompt string, pembaca *bufio.Reader) string {
	fmt.Print(prompt)
	input, _ := pembaca.ReadString('\n')
	return strings.TrimSpace(input)
}

func bacaInputInt(prompt string, pembaca *bufio.Reader) (int, error) {
	fmt.Print(prompt)
	inputStr, _ := pembaca.ReadString('\n')
	val, err := strconv.Atoi(strings.TrimSpace(inputStr))
	if err != nil {
		return 0, err
	}
	return val, nil
}

func cariPengguna(usernameCari string) (int, *Pengguna) {
	for i := 0; i < jumlahPengguna; i++ {
		if dataPengguna[i].username == usernameCari {
			return i, &dataPengguna[i]
		}
	}
	return -1, nil
}

func registrasiPengguna(usernameBaru, passwordBaru string, peranBaru string, pembaca *bufio.Reader) bool {
	if jumlahPengguna >= MAKS_PENGGUNA {
		fmt.Println("Kapasitas pengguna penuh. Tidak bisa mendaftar.")
		return false
	}
	if _, penggunaAda := cariPengguna(usernameBaru); penggunaAda != nil {
		fmt.Println("Username sudah ada. Silakan pilih username lain.")
		return false
	}

	dataPengguna[jumlahPengguna] = Pengguna{username: usernameBaru, password: passwordBaru, peran: peranBaru}
	jumlahPengguna++
	fmt.Printf("Pengguna '%s' dengan peran '%s' berhasil terdaftar.\n", usernameBaru, peranBaru)
	return true
}

func prosesLogin(pembaca *bufio.Reader) (string, string) {
	for {
		fmt.Println("\n===== SELAMAT DATANG DI MANAJEMEN BUKU & KOMENTAR =====")
		fmt.Println("Silakan Login atau Daftar untuk melanjutkan:")
		fmt.Println("1. Login")
		fmt.Println("2. Register")
		fmt.Println("0. Keluar Program")

		pilihanMenu, err := bacaInputInt("Pilihan Anda: ", pembaca)
		if err != nil {
			fmt.Println("Pilihan tidak valid. Masukkan angka.")
			continue
		}

		switch pilihanMenu {
		case 0:
			return "", "exit"
		case 1:
			inputUsername := bacaInputString("Username: ", pembaca)
			inputPassword := bacaInputString("Password: ", pembaca)

			_, pengguna := cariPengguna(inputUsername)
			if pengguna != nil && pengguna.password == inputPassword {
				fmt.Printf("Login sebagai %s (%s) berhasil.\n", pengguna.username, pengguna.peran)
				return pengguna.username, pengguna.peran
			} else {
				fmt.Println("Username atau password salah. Coba lagi.")
			}
		case 2:
			fmt.Println("\n--- Pendaftaran Akun User Baru ---")
			newUsername := bacaInputString("Masukkan Username baru: ", pembaca)
			if newUsername == "" {
				fmt.Println("Username tidak boleh kosong.")
				continue
			}
			newPassword := bacaInputString("Masukkan Password baru: ", pembaca)
			if newPassword == "" {
				fmt.Println("Password tidak boleh kosong.")
				continue
			}
			registrasiPengguna(newUsername, newPassword, PERAN_USER, pembaca)
		default:
			fmt.Println("Pilihan tidak valid.")
		}
	}
}

func tambahBukuBaru(newJudul, newPenulis string, newTahun int, newSinopsis string) {
	if jumlahBuku < MAKS_BUKU {
		dataBuku[jumlahBuku] = Buku{judul: newJudul, penulis: newPenulis, tahun: newTahun, sinopsis: newSinopsis}
		jumlahBuku++
		fmt.Println("Buku berhasil ditambahkan.")
	} else {
		fmt.Println("Penyimpanan buku penuh.")
	}
}

func tampilkanSemuaBuku(tampilkanSinopsis bool) {
	if jumlahBuku == 0 {
		fmt.Println("Belum ada buku.")
		return
	}
	fmt.Println("\n--- Daftar Buku ---")
	for i := 0; i < jumlahBuku; i++ {
		b := dataBuku[i]
		fmt.Printf("%d. Judul: %s\n   Penulis: %s\n   Tahun: %d\n", i+1, b.judul, b.penulis, b.tahun)
		if tampilkanSinopsis && b.sinopsis != "" {
			fmt.Printf("   Sinopsis: %s\n", b.sinopsis)
		} else if tampilkanSinopsis && b.sinopsis == "" {
			fmt.Println("   Sinopsis: (Belum tersedia)")
		}
		fmt.Println("   --------------------")
	}
}

func cariBukuJudul(targetJudul string) int {
	for i := 0; i < jumlahBuku; i++ {
		if strings.EqualFold(dataBuku[i].judul, targetJudul) {
			return i
		}
	}
	return -1
}

func cariBinerJudul(targetJudul string) int {
	low := 0
	high := jumlahBuku - 1
	for low <= high {
		mid := (low + high) / 2
		comp := strings.Compare(strings.ToLower(dataBuku[mid].judul), strings.ToLower(targetJudul))
		if comp == 0 {
			return mid
		} else if comp < 0 {
			low = mid + 1
		} else {
			high = mid - 1
		}
	}
	return -1
}

func ubahBuku(indeks int, editJudul, editPenulis string, editTahun int, editSinopsis string) {
	if indeks < 0 || indeks >= jumlahBuku {
		fmt.Println("Indeks buku tidak valid untuk diubah.")
		return
	}
	dataBuku[indeks].judul = editJudul
	dataBuku[indeks].penulis = editPenulis
	dataBuku[indeks].tahun = editTahun
	dataBuku[indeks].sinopsis = editSinopsis
	fmt.Println("Data buku berhasil diubah.")
}

func kelolaSinopsisAdmin(pembaca *bufio.Reader) {
	tampilkanSemuaBuku(false)
	if jumlahBuku == 0 {
		return
	}
	pilihanBuku, errPilihan := bacaInputInt(fmt.Sprintf("Pilih nomor buku yang ingin ditambah/diubah sinopsisnya (1-%d): ", jumlahBuku), pembaca)
	if errPilihan != nil || pilihanBuku < 1 || pilihanBuku > jumlahBuku {
		fmt.Println("Pilihan buku tidak valid.")
		return
	}
	indeks := pilihanBuku - 1
	b := dataBuku[indeks]
	fmt.Printf("Buku dipilih: %s\n", b.judul)
	if b.sinopsis != "" {
		fmt.Printf("Sinopsis saat ini: %s\n", b.sinopsis)
	} else {
		fmt.Println("Belum ada sinopsis untuk buku ini.")
	}
	newSynopsis := bacaInputString("Masukkan sinopsis baru (kosongkan jika tidak ingin mengubah): ", pembaca)
	if newSynopsis != "" {
		dataBuku[indeks].sinopsis = newSynopsis
		fmt.Println("Sinopsis berhasil diperbarui.")
	} else if b.sinopsis != "" && newSynopsis == "" {
		fmt.Println("Sinopsis tidak diubah.")
	} else {
		fmt.Println("Tidak ada sinopsis baru yang dimasukkan.")
	}
}

func lihatSinopsisPengguna(pembaca *bufio.Reader) {
	tampilkanSemuaBuku(false)
	if jumlahBuku == 0 {
		return
	}
	pilihanBuku, errPilihan := bacaInputInt(fmt.Sprintf("Pilih nomor buku yang ingin dilihat sinopsisnya (1-%d): ", jumlahBuku), pembaca)
	if errPilihan != nil || pilihanBuku < 1 || pilihanBuku > jumlahBuku {
		fmt.Println("Pilihan buku tidak valid.")
		return
	}
	indeks := pilihanBuku - 1
	b := dataBuku[indeks]
	fmt.Printf("\n--- Sinopsis untuk: %s ---\n", b.judul)
	if b.sinopsis != "" {
		fmt.Println(b.sinopsis)
	} else {
		fmt.Println("(Sinopsis belum tersedia untuk buku ini)")
	}
}

func hapusBuku(indeks int) {
	if indeks < 0 || indeks >= jumlahBuku {
		fmt.Println("Indeks buku tidak valid untuk dihapus.")
		return
	}
	fmt.Printf("Menghapus buku: %s. Komentar terkait buku ini mungkin menjadi tidak valid.\n", dataBuku[indeks].judul)

	for i := indeks; i < jumlahBuku-1; i++ {
		dataBuku[i] = dataBuku[i+1]
	}
	jumlahBuku--
	if jumlahBuku < MAKS_BUKU {
		dataBuku[jumlahBuku] = Buku{}
	}
	fmt.Println("Buku berhasil dihapus.")
}

func urutkanBukuJudul(ascending bool) {
	if jumlahBuku == 0 {
		fmt.Println("Tidak ada buku untuk diurutkan.")
		return
	}
	for i := 0; i < jumlahBuku-1; i++ {
		idxMinMax := i
		for j := i + 1; j < jumlahBuku; j++ {
			comp := strings.Compare(strings.ToLower(dataBuku[j].judul), strings.ToLower(dataBuku[idxMinMax].judul))
			if (ascending && comp < 0) || (!ascending && comp > 0) {
				idxMinMax = j
			}
		}
		dataBuku[i], dataBuku[idxMinMax] = dataBuku[idxMinMax], dataBuku[i]
	}
	if ascending {
		fmt.Println("Buku diurutkan berdasarkan judul (A-Z).")
	} else {
		fmt.Println("Buku diurutkan berdasarkan judul (Z-A).")
	}
}

func urutkanBukuTahun(ascending bool) {
	if jumlahBuku == 0 {
		fmt.Println("Tidak ada buku untuk diurutkan.")
		return
	}
	for i := 1; i < jumlahBuku; i++ {
		key := dataBuku[i]
		j := i - 1
		for j >= 0 && ((ascending && dataBuku[j].tahun > key.tahun) || (!ascending && dataBuku[j].tahun < key.tahun)) {
			dataBuku[j+1] = dataBuku[j]
			j--
		}
		dataBuku[j+1] = key
	}
	if ascending {
		fmt.Println("Buku diurutkan berdasarkan tahun (Lama ke Baru).")
	} else {
		fmt.Println("Buku diurutkan berdasarkan tahun (Baru ke Lama).")
	}
}

func tambahKomentarBalasan(uPengomentar, konten string, idxBuku int, adalahBalasan bool, idxKomentarInduk int) {
	if idxBuku < 0 || idxBuku >= jumlahBuku {
		fmt.Println("Buku yang dikomentari tidak valid.")
		return
	}
	if jumlahKomentar < MAKS_KOMENTAR {
		dataKomentar[jumlahKomentar] = Komentar{
			usernamePengomentar: uPengomentar,
			isiKomentar:         konten,
			indeksBuku:          idxBuku,
			merupakanBalasan:    adalahBalasan,
			indeksKomentarInduk: idxKomentarInduk,
		}
		jumlahKomentar++
		if adalahBalasan {
			fmt.Println("Balasan berhasil ditambahkan.")
		} else {
			fmt.Println("Komentar berhasil ditambahkan.")
		}
	} else {
		fmt.Println("Kapasitas komentar penuh.")
	}
}

func tampilkanSemuaKomentar() {
	if jumlahKomentar == 0 {
		fmt.Println("Belum ada komentar.")
		return
	}
	fmt.Println("\n--- Daftar Komentar & Balasan ---")
	for i := 0; i < jumlahKomentar; i++ {
		k := dataKomentar[i]
		prefixKomentar := "Komentar"
		infoInduk := ""

		if k.indeksBuku < 0 || k.indeksBuku >= jumlahBuku {
			fmt.Printf("%d. Data komentar error: Indeks buku tidak valid untuk komentar oleh @%s\n", i+1, k.usernamePengomentar)
			continue
		}
		bukuTerkait := dataBuku[k.indeksBuku]

		if k.merupakanBalasan {
			prefixKomentar = "Balasan"
			if k.indeksKomentarInduk >= 0 && k.indeksKomentarInduk < jumlahKomentar {
				komentarInduk := dataKomentar[k.indeksKomentarInduk]
				previewKontenInduk := komentarInduk.isiKomentar
				if len(previewKontenInduk) > 30 {
					previewKontenInduk = previewKontenInduk[:27] + "..."
				}
				infoInduk = fmt.Sprintf(" (membalas komentar %d: \"%s\")", k.indeksKomentarInduk+1, previewKontenInduk)
			} else {
				infoInduk = " (membalas komentar yang mungkin telah dihapus)"
			}
		}

		fmt.Printf("%d. [%s oleh @%s]%s\n   Untuk Buku: \"%s\" oleh %s\n   Isi: %s\n   --------------------\n",
			i+1, prefixKomentar, k.usernamePengomentar, infoInduk, bukuTerkait.judul, bukuTerkait.penulis, k.isiKomentar)
	}
}

func tampilkanMenuAdmin(usernameLogin string, pembaca *bufio.Reader) {
	for {
		fmt.Println("\n===== MENU ADMIN =====")
		fmt.Println("--- Manajemen Buku ---")
		fmt.Println("1. Tampilkan Semua Buku")
		fmt.Println("2. Tambah Buku Baru")
		fmt.Println("3. Cari Buku (Judul - Sequential)")
		fmt.Println("4. Cari Buku (Judul - Binary)")
		fmt.Println("5. Edit Data Buku (Sequential Search)")
		fmt.Println("6. Edit Data Buku (Binary Search)")
		fmt.Println("7. Hapus Buku (Sequential Search)")
		fmt.Println("8. Hapus Buku (Binary Search)")
		fmt.Println("9. Urutkan Buku berdasarkan Judul (A-Z)")
		fmt.Println("10. Urutkan Buku berdasarkan Tahun Terbit (Lama ke Baru)")
		fmt.Println("11. Tambah/Ubah Sinopsis Buku")
		fmt.Println("--- Manajemen Komentar (Admin) ---")
		fmt.Println("12. Tampilkan Semua Komentar")
		fmt.Println("13. Tambah Komentar tentang Buku (sebagai Admin)")
		fmt.Println("14. Balas Komentar (sebagai Admin)")
		fmt.Println("--- Manajemen Pengguna ---")
		fmt.Println("15. Tambah Admin Baru")
		fmt.Println("0. Logout")

		pilihanMenu, err := bacaInputInt("Pilih menu: ", pembaca)
		if err != nil {
			fmt.Println("Input tidak valid. Masukkan angka.")
			continue
		}

		switch pilihanMenu {
		case 0:
			fmt.Println("Logout berhasil. Kembali ke halaman login.")
			return
		case 1:
			tampilkanSemuaBuku(true)
		case 2:
			judulInput := bacaInputString("Judul Buku: ", pembaca)
			penulisInput := bacaInputString("Penulis Buku: ", pembaca)
			tahunInput, errTahun := bacaInputInt("Tahun Terbit: ", pembaca)
			if errTahun != nil {
				fmt.Println("Tahun terbit tidak valid.")
				continue
			}
			sinopsisInput := bacaInputString("Sinopsis Buku (opsional): ", pembaca)
			tambahBukuBaru(judulInput, penulisInput, tahunInput, sinopsisInput)
		case 3:
			targetJudul := bacaInputString("Judul buku yang dicari: ", pembaca)
			indeks := cariBukuJudul(targetJudul)
			if indeks != -1 {
				b := dataBuku[indeks]
				fmt.Printf("Ditemukan: Judul: %s, Penulis: %s, Tahun: %d\n", b.judul, b.penulis, b.tahun)
				if b.sinopsis != "" {
					fmt.Printf("Sinopsis: %s\n", b.sinopsis)
				}
			} else {
				fmt.Println("Buku tidak ditemukan.")
			}
		case 4:
			urutkanBukuJudul(true)
			targetJudul := bacaInputString("Judul buku yang dicari (setelah diurutkan): ", pembaca)
			indeks := cariBinerJudul(targetJudul)
			if indeks != -1 {
				b := dataBuku[indeks]
				fmt.Printf("Ditemukan: Judul: %s, Penulis: %s, Tahun: %d\n", b.judul, b.penulis, b.tahun)
				if b.sinopsis != "" {
					fmt.Printf("Sinopsis: %s\n", b.sinopsis)
				}
			} else {
				fmt.Println("Buku tidak ditemukan.")
			}
		case 5:
			targetJudulEdit := bacaInputString("Judul buku yang ingin diubah: ", pembaca)
			indeks := cariBukuJudul(targetJudulEdit)
			if indeks != -1 {
				b := dataBuku[indeks]
				fmt.Println("Buku ditemukan:", b.judul)
				editJudul := bacaInputString("Judul baru (kosongkan jika tidak berubah): ", pembaca)
				if editJudul == "" {
					editJudul = b.judul
				}
				editPenulis := bacaInputString("Penulis baru (kosongkan jika tidak berubah): ", pembaca)
				if editPenulis == "" {
					editPenulis = b.penulis
				}
				fmt.Printf("Tahun saat ini: %d. Masukkan tahun baru (angka, kosongkan jika tidak berubah): ", b.tahun)
				strEditTahun := bacaInputString("", pembaca)
				editTahun := b.tahun
				if strEditTahun != "" {
					parsedTahun, errParse := strconv.Atoi(strEditTahun)
					if errParse != nil {
						fmt.Println("Format tahun baru tidak valid. Tahun tidak diubah.")
					} else {
						editTahun = parsedTahun
					}
				}
				fmt.Printf("Sinopsis saat ini: %s\n", b.sinopsis)
				editSinopsis := bacaInputString("Sinopsis baru (kosongkan jika tidak berubah, ketik 'hapus' untuk mengosongkan): ", pembaca)
				if strings.ToLower(editSinopsis) == "hapus" {
					editSinopsis = ""
				} else if editSinopsis == "" {
					editSinopsis = b.sinopsis
				}
				ubahBuku(indeks, editJudul, editPenulis, editTahun, editSinopsis)
			} else {
				fmt.Println("Buku tidak ditemukan.")
			}
		case 6:
			urutkanBukuJudul(true)
			targetJudulEdit := bacaInputString("Judul buku yang ingin diubah (setelah diurutkan): ", pembaca)
			indeks := cariBinerJudul(targetJudulEdit)
			if indeks != -1 {
				b := dataBuku[indeks]
				fmt.Println("Buku ditemukan:", b.judul)
				editJudul := bacaInputString("Judul baru (kosongkan jika tidak berubah): ", pembaca)
				if editJudul == "" {
					editJudul = b.judul
				}
				editPenulis := bacaInputString("Penulis baru (kosongkan jika tidak berubah): ", pembaca)
				if editPenulis == "" {
					editPenulis = b.penulis
				}
				fmt.Printf("Tahun saat ini: %d. Masukkan tahun baru (angka, kosongkan jika tidak berubah): ", b.tahun)
				strEditTahun := bacaInputString("", pembaca)
				editTahun := b.tahun
				if strEditTahun != "" {
					parsedTahun, errParse := strconv.Atoi(strEditTahun)
					if errParse != nil {
						fmt.Println("Format tahun baru tidak valid. Tahun tidak diubah.")
					} else {
						editTahun = parsedTahun
					}
				}
				fmt.Printf("Sinopsis saat ini: %s\n", b.sinopsis)
				editSinopsis := bacaInputString("Sinopsis baru (kosongkan jika tidak berubah, ketik 'hapus' untuk mengosongkan): ", pembaca)
				if strings.ToLower(editSinopsis) == "hapus" {
					editSinopsis = ""
				} else if editSinopsis == "" {
					editSinopsis = b.sinopsis
				}
				ubahBuku(indeks, editJudul, editPenulis, editTahun, editSinopsis)
			} else {
				fmt.Println("Buku tidak ditemukan.")
			}
		case 7:
			targetJudulHapus := bacaInputString("Judul buku yang ingin dihapus: ", pembaca)
			indeks := cariBukuJudul(targetJudulHapus)
			if indeks != -1 {
				hapusBuku(indeks)
			} else {
				fmt.Println("Buku tidak ditemukan.")
			}
		case 8:
			urutkanBukuJudul(true)
			targetJudulHapus := bacaInputString("Judul buku yang ingin dihapus (setelah diurutkan): ", pembaca)
			indeks := cariBinerJudul(targetJudulHapus)
			if indeks != -1 {
				hapusBuku(indeks)
			} else {
				fmt.Println("Buku tidak ditemukan.")
			}
		case 9:
			urutkanBukuJudul(true)
		case 10:
			urutkanBukuTahun(true)
		case 11:
			kelolaSinopsisAdmin(pembaca)
		case 12:
			tampilkanSemuaKomentar()
		case 13:
			tampilkanSemuaBuku(false)
			if jumlahBuku == 0 {
				fmt.Println("Tidak ada buku untuk dikomentari.")
				continue
			}
			pilihanBukuKomentar, errPilihan := bacaInputInt(fmt.Sprintf("Pilih nomor buku yang ingin dikomentari (1-%d): ", jumlahBuku), pembaca)
			if errPilihan != nil || pilihanBukuKomentar < 1 || pilihanBukuKomentar > jumlahBuku {
				fmt.Println("Pilihan buku tidak valid.")
				continue
			}
			isiKomentarAdmin := bacaInputString("Isi komentar Anda (sebagai Admin): ", pembaca)
			if isiKomentarAdmin == "" {
				fmt.Println("Komentar tidak boleh kosong.")
				continue
			}
			tambahKomentarBalasan(usernameLogin, isiKomentarAdmin, pilihanBukuKomentar-1, false, -1)
		case 14:
			tampilkanSemuaKomentar()
			if jumlahKomentar == 0 {
				fmt.Println("Tidak ada komentar untuk dibalas.")
				continue
			}
			pilihanKomentarBalas, errPilihanK := bacaInputInt(fmt.Sprintf("Pilih nomor komentar yang ingin dibalas (1-%d): ", jumlahKomentar), pembaca)
			if errPilihanK != nil || pilihanKomentarBalas < 1 || pilihanKomentarBalas > jumlahKomentar {
				fmt.Println("Pilihan komentar tidak valid.")
				continue
			}
			indeksInduk := pilihanKomentarBalas - 1
			komentarAsli := dataKomentar[indeksInduk]
			if komentarAsli.indeksBuku < 0 || komentarAsli.indeksBuku >= jumlahBuku {
				fmt.Println("Komentar yang dipilih merujuk pada buku yang tidak valid atau telah dihapus.")
				continue
			}
			fmt.Printf("Membalas komentar: \"%s\" oleh @%s tentang buku \"%s\"\n", komentarAsli.isiKomentar, komentarAsli.usernamePengomentar, dataBuku[komentarAsli.indeksBuku].judul)
			isiBalasanAdmin := bacaInputString("Isi balasan Anda (sebagai Admin): ", pembaca)
			if isiBalasanAdmin == "" {
				fmt.Println("Balasan tidak boleh kosong.")
				continue
			}
			tambahKomentarBalasan(usernameLogin, isiBalasanAdmin, komentarAsli.indeksBuku, true, indeksInduk)
		case 15:
			fmt.Println("\n--- Pendaftaran Admin Baru ---")
			usernameAdminBaru := bacaInputString("Masukkan Username admin baru: ", pembaca)
			if usernameAdminBaru == "" {
				fmt.Println("Username tidak boleh kosong.")
				continue
			}
			passwordAdminBaru := bacaInputString("Masukkan Password admin baru: ", pembaca)
			if passwordAdminBaru == "" {
				fmt.Println("Password tidak boleh kosong.")
				continue
			}
			registrasiPengguna(usernameAdminBaru, passwordAdminBaru, PERAN_ADMIN, pembaca)
		default:
			fmt.Println("Pilihan tidak valid.")
		}
	}
}

func tampilkanMenuPengguna(usernameLogin string, pembaca *bufio.Reader) {
	for {
		fmt.Printf("\n===== MENU USER (%s) =====\n", usernameLogin)
		fmt.Println("--- Buku ---")
		fmt.Println("1. Tampilkan Semua Buku")
		fmt.Println("2. Cari Buku (Judul - Sequential)")
		fmt.Println("3. Cari Buku (Judul - Binary)")
		fmt.Println("4. Urutkan Buku berdasarkan Judul (A-Z)")
		fmt.Println("5. Urutkan Buku berdasarkan Tahun Terbit (Lama ke Baru)")
		fmt.Println("6. Lihat Sinopsis Buku")
		fmt.Println("--- Interaksi ---")
		fmt.Println("7. Tambah Komentar tentang Buku")
		fmt.Println("8. Balas Komentar")
		fmt.Println("9. Tampilkan Semua Komentar")
		fmt.Println("0. Logout")

		pilihanMenu, err := bacaInputInt("Pilih menu: ", pembaca)
		if err != nil {
			fmt.Println("Input tidak valid. Masukkan angka.")
			continue
		}

		switch pilihanMenu {
		case 0:
			fmt.Println("Kembali...")
			return
		case 1:
			tampilkanSemuaBuku(false)
		case 2:
			targetJudul := bacaInputString("Judul buku yang dicari: ", pembaca)
			indeks := cariBukuJudul(targetJudul)
			if indeks != -1 {
				b := dataBuku[indeks]
				fmt.Printf("Ditemukan: Judul: %s, Penulis: %s, Tahun: %d\n", b.judul, b.penulis, b.tahun)
			} else {
				fmt.Println("Buku tidak ditemukan.")
			}
		case 3:
			urutkanBukuJudul(true)
			targetJudul := bacaInputString("Judul buku yang dicari (setelah diurutkan): ", pembaca)
			indeks := cariBinerJudul(targetJudul)
			if indeks != -1 {
				b := dataBuku[indeks]
				fmt.Printf("Ditemukan: Judul: %s, Penulis: %s, Tahun: %d\n", b.judul, b.penulis, b.tahun)
			} else {
				fmt.Println("Buku tidak ditemukan.")
			}
		case 4:
			urutkanBukuJudul(true)
		case 5:
			urutkanBukuTahun(true)
		case 6:
			lihatSinopsisPengguna(pembaca)
		case 7:
			tampilkanSemuaBuku(false)
			if jumlahBuku == 0 {
				fmt.Println("Tidak ada buku untuk dikomentari.")
				continue
			}
			pilihanBukuKomentar, errPilihan := bacaInputInt(fmt.Sprintf("Pilih nomor buku yang ingin dikomentari (1-%d): ", jumlahBuku), pembaca)
			if errPilihan != nil || pilihanBukuKomentar < 1 || pilihanBukuKomentar > jumlahBuku {
				fmt.Println("Pilihan buku tidak valid.")
				continue
			}
			isiKomentarUser := bacaInputString("Isi komentar Anda: ", pembaca)
			if isiKomentarUser == "" {
				fmt.Println("Komentar tidak boleh kosong.")
				continue
			}
			tambahKomentarBalasan(usernameLogin, isiKomentarUser, pilihanBukuKomentar-1, false, -1)
		case 8:
			tampilkanSemuaKomentar()
			if jumlahKomentar == 0 {
				fmt.Println("Tidak ada komentar untuk dibalas.")
				continue
			}
			pilihanKomentarBalas, errPilihanK := bacaInputInt(fmt.Sprintf("Pilih nomor komentar yang ingin dibalas (1-%d): ", jumlahKomentar), pembaca)
			if errPilihanK != nil || pilihanKomentarBalas < 1 || pilihanKomentarBalas > jumlahKomentar {
				fmt.Println("Pilihan komentar tidak valid.")
				continue
			}
			indeksInduk := pilihanKomentarBalas - 1
			komentarAsli := dataKomentar[indeksInduk]
			if komentarAsli.indeksBuku < 0 || komentarAsli.indeksBuku >= jumlahBuku {
				fmt.Println("Komentar yang dipilih merujuk pada buku yang tidak valid atau telah dihapus.")
				continue
			}
			fmt.Printf("Membalas komentar: \"%s\" oleh @%s tentang buku \"%s\"\n", komentarAsli.isiKomentar, komentarAsli.usernamePengomentar, dataBuku[komentarAsli.indeksBuku].judul)
			isiBalasanUser := bacaInputString("Isi balasan Anda: ", pembaca)
			if isiBalasanUser == "" {
				fmt.Println("Balasan tidak boleh kosong.")
				continue
			}
			tambahKomentarBalasan(usernameLogin, isiBalasanUser, komentarAsli.indeksBuku, true, indeksInduk)
		case 9:
			tampilkanSemuaKomentar()
		default:
			fmt.Println("Pilihan tidak valid.")
		}
	}
}

func main() {
	dataPengguna[jumlahPengguna] = Pengguna{username: "admin", password: "admin123", peran: PERAN_ADMIN}
	jumlahPengguna++
	fmt.Println("Akun admin default dibuat: username 'admin', password 'admin123'")

	tambahBukuBaru("Laskar Pelangi", "Andrea Hirata", 2005, "Kisah inspiratif anak-anak Belitung yang berjuang untuk pendidikan.")
	tambahBukuBaru("Bumi", "Tere Liye", 2014, "Petualangan Raib, Seli, dan Ali di dunia paralel.")
	tambahBukuBaru("Ayat-Ayat Cinta", "Habiburrahman El Shirazy", 2004, "Kisah cinta Fahri di tengah kehidupan Mesir.")
	tambahBukuBaru("Perahu Kertas", "Dee Lestari", 2009, "Cerita tentang Kugy dan Keenan yang menemukan takdir mereka.")

	tambahKomentarBalasan("userA", "Buku Laskar Pelangi sangat menginspirasi!", 0, false, -1)
	tambahKomentarBalasan("userB", "Setuju, saya suka karakter Ikal.", 0, true, 0)
	tambahKomentarBalasan("userC", "Bumi adalah novel fantasi favorit saya.", 1, false, -1)

	pembaca := bufio.NewReader(os.Stdin)
	var usernameLoginSaatIni, peranLoginSaatIni string

	for {
		usernameLoginSaatIni, peranLoginSaatIni = prosesLogin(pembaca)

		if peranLoginSaatIni == "exit" {
			fmt.Println("Terima kasih! Program selesai.")
			return
		}

		if peranLoginSaatIni == PERAN_ADMIN {
			tampilkanMenuAdmin(usernameLoginSaatIni, pembaca)
		} else if peranLoginSaatIni == PERAN_USER {
			tampilkanMenuPengguna(usernameLoginSaatIni, pembaca)
		}
	}
}
